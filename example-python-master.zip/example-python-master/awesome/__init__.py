def smile():
    return ":)"

def frown():
    return ":("
